from django.apps import AppConfig


class Hospital1Config(AppConfig):
    name = 'hospital1'
